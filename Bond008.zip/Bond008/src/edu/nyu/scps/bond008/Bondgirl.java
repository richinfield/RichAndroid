package edu.nyu.scps.bond008;

import java.io.IOException;

import android.app.Activity;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.RadioButton;
import android.widget.RatingBar;
import android.widget.RatingBar.OnRatingBarChangeListener;
import android.widget.Spinner;
import android.widget.Toast;
import android.widget.ToggleButton;

public class Bondgirl extends Activity {
    /** Called when the activity is first created. */
    public String girlselected;
    private String imgselected;
    private String rbtext = "";
//    private TextView tvs = (TextView)findViewById(R.id.girlsumm);
	private boolean togglestat = false;
    private String toggleString = "";
    private float girlrating;
//	private TextView tv2 = (TextView)findViewById(R.id.editText2);
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        Spinner spinner = (Spinner) findViewById(R.id.spinner1);
//      ArrayAdapter<String> adapter = new ArrayAdapter<String> 
//      (this,android.R.layout.simple_spinner_item, bondgirls); 
      ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
              this, R.array.grls, android.R.layout.simple_spinner_item);
      adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
      spinner.setAdapter(adapter);
     
     spinner.setOnItemSelectedListener(new OnItemSelectedListener() {
      	public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
      		girlselected = parent.getItemAtPosition(pos).toString();
      		TextView tv1 = (TextView)findViewById(R.id.girlsumm);
      		tv1.setText("");
            final RatingBar ratebar = (RatingBar)findViewById(R.id.heatratingBar);
            ratebar.setRating(0);
      		
      		ToggleButton toggle1 = (ToggleButton)findViewById(R.id.toggle1);
      		toggle1.setChecked(true);
//      		EditText et = (EditText)findViewById(R.id.editText1);
//      		et.setText(girlselected);
//      		Toast.makeText(Bondgirl.this, "Your babe is " +
//      				girlselected.split(" ")[0] + " pic is " + girlselected.split(" ")[0].toLowerCase()+".jpg", Toast.LENGTH_LONG).show();

      		ImageView iv = (ImageView)findViewById(R.id.image1);
      		imgselected = girlselected.split(" ")[0].toLowerCase() + ".jpg";
      		Drawable drawable = null;
			try {
				drawable = Drawable.createFromStream(getAssets().open(imgselected), null);
			} catch (IOException e) {
				Toast.makeText(Bondgirl.this,"No image " + imgselected + " found", Toast.LENGTH_LONG).show();
//				e.printStackTrace();
			}
      		iv.setImageDrawable(drawable);

            //This listener will be the listener for all three radio button
            final OnClickListener radioListener = new OnClickListener() {
                public void onClick(View v) {
                    RadioButton rb = (RadioButton)v;
                    rbtext = (String) rb.getText();
//                    tv2.setText("She is " + rb.getText());
//                    Toast.makeText(Bondgirl.this, rb.getText(), Toast.LENGTH_SHORT).show();
                    displayStatusLine();
                }
            };
            
            final RadioButton blonde = (RadioButton)findViewById(R.id.blonde);
            blonde.setOnClickListener(radioListener);
            
            final RadioButton brunette = (RadioButton)findViewById(R.id.brunette);
            brunette.setOnClickListener(radioListener);
            
            final RadioButton bald = (RadioButton)findViewById(R.id.bald);
            bald.setOnClickListener(radioListener);

//            final RatingBar ratebar = (RatingBar)findViewById(R.id.heatratingBar);
            ratebar.setOnRatingBarChangeListener(new OnRatingBarChangeListener() {
                public void onRatingChanged(RatingBar ratebar, float rating, boolean fromUser) {
//                	Toast.makeText(Bondgirl.this, "New Rating: " + rating, Toast.LENGTH_SHORT).show();
                	girlrating = rating;
                    displayStatusLine();
                }
            });
 
//            ToggleButton toggle2 = (ToggleButton)findViewById(R.id.toggle1);
            
            toggle1.setOnClickListener(new OnClickListener() {
                public void onClick(View v) {
                	boolean b = ((ToggleButton)v).isPressed();
                	togglestat = !togglestat; 
                	toggleString = togglestat? "Alive" : "Dead";
//                    Toast toast = Toast.makeText(Bondgirl.this, toggleString, Toast.LENGTH_SHORT);
//                    toast.show();
//                    Toast.makeText(Bondgirl.this, toggleString, Toast.LENGTH_SHORT).show();
//                    tvs.setVisibility(0);
                    displayStatusLine();
                }
           });
      	}

      	public void displayStatusLine() {
//            String indef = ((toggleString.toLowerCase()).matches("^[aeiou]"))? "an" : "a";
            String indef = toggleString.toLowerCase() == "alive" ? "an" : "a";
            TextView tv1 = (TextView)findViewById(R.id.girlsumm);
            tv1.setText(girlselected + " is " + indef + " " + toggleString.toLowerCase() + " " + rbtext.toLowerCase() + " Bond girl rated " + girlrating);                
      	}
            
      	public void onNothingSelected(AdapterView parent) {
      		// Do nothing.
      	}
      	
     });        
    }
        
    static final String[] bondgirls = {
        	"Ursula Andress", "Eunice Gayson", "Daniela Bianchi", "Honor Blackman", 
        	"Mie Hama", "Diana Rigg", "Jill St. John", "Jane Seymour", "Britt Ekland", "Carole Bouquet"
    };
    }